package com.example.building3.SSD

data class SSD(
    val name: String,
    val storagePrice: String,
    val NVMestatus: String,
    val amountOfMemory: String,
    val url: String
)
