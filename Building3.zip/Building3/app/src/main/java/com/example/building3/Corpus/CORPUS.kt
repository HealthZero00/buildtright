package com.example.building3.Corpus

data class CORPUS(
    val name: String,
    val case_price: String,
    val url: String
)
