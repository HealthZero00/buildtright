package com.example.building3.Motherboards

data class MOTHERBOARDS(
    val name: String,
    val brand: String,
    val formFactor: String,
    val price: String,
    val socket: String,
    val chipset: String,
    val memoryType: String,
    val url: String
)
