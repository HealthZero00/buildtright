package com.example.building3.Powersupplies

data class POWERSUPPLIES(
    val name: String,
    val powersupplies_rating: String,
    val power: String,
    val powersupplies_price: String,
    val url: String
)

