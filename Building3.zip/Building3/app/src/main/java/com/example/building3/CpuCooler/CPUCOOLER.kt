package com.example.building3.CpuCooler

data class CPUCOOLER(
    val name: String,
    val price: String,
    val url: String
)
