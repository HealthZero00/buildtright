package com.example.building3.RAM

data class RAM(
    val name: String,
    val price: String,
    val typeMemory: String,
    val amountOfMemory: String,
    val url: String
)
