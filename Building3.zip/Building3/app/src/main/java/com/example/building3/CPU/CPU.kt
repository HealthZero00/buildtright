package com.example.building3.CPU

data class CPU(val name: String, val brand: String, val model: String, val price: String, val socket: String, val url: String)

